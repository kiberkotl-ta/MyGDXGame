package com.mygdx.game;

public class Comics implements Screen{


}
